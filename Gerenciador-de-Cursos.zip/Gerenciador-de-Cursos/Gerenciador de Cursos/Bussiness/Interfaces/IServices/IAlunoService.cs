﻿namespace Gerenciador_de_Cursos.Bussiness.Interfaces.IService
{
    public interface IAlunoService
    {
    }
}
