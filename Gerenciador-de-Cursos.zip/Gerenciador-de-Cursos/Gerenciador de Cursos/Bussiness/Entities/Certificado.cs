﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Certificado
    {
        public Guid Id { get; set; }

        public Curso Curso { get; set; }
        public Aluno Aluno { get; set; }
        public Curso CargaHoraria { get; set; }
        public AlunoCurso Inicio { get; set; }
        public AlunoCurso Termino {  get; set; }

        //Assinatura do aluno por INGOV

    }
}
