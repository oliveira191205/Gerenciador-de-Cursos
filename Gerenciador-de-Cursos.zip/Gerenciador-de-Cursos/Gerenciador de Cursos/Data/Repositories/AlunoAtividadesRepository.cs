﻿using Gerenciador_de_Cursos.Bussiness.Entities;
using Gerenciador_de_Cursos.Data.Context;
using Gerenciador_de_Cursos.Bussiness.Interfaces.IRepositories;
using Microsoft.EntityFrameworkCore;

namespace Gerenciador_de_Cursos.Data.Repositories
{
    public class AlunoAtividadesRepository : IAlunoAtividadesRepository
    {
        private readonly DataContext _db;

        public AlunoAtividadesRepository(DataContext db)
        {
            _db = db;
        }

        public void CreateAlunoAtividades(AlunoAtividades alunoAtividade)
        {
            _db.AlunoAtividades.Add(alunoAtividade); // tem q fazer o DataContext para parar de dar erro 
            _db.SaveChanges();
        }

        public AlunoAtividades FindById(Guid id)
        {
            return _db.AlunoAtividades
                .Select(alunoatividades => alunoatividades)
                .Where(alunoatividades => alunoatividades.Id == id)
                .First();
        }

        public List<AlunoAtividades> GetAlunoAtividades()
        {
            List<AlunoAtividades> result = _db.AlunoAtividades
                .Select(alunoatividades => alunoatividades)
                .ToList();

            return result;
        }

        public List<AlunoAtividades> GetAtividadesByAlunoId(Guid alunoId)
        {
            List<AlunoAtividades> result = _db.AlunoAtividades
                .Select(alunoatividades => alunoatividades)
                .Where(alunoatividades => alunoatividades.AlunoId == alunoId)
                .ToList();

            return result;

        }

        public List<AlunoAtividades> GetAlunosByAtividadeId(Guid atividadeId)
        {
            List<AlunoAtividades> result = _db.AlunoAtividades
                .Select(alunoatividades => alunoatividades)
                .Where(alunoatividades => alunoatividades.AtividadesCursoId == atividadeId)
                .ToList();

            return result;
        }
    }
}
