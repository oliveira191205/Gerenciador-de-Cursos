﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Curso
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
        public string Descrição { get; set; }
        public int CargaHoraria { get; set; }


        public Guid InstrutorId { get; set; }
        public Instrutor Instrutor { get; set; }

        public int LimiteTurma { get; set; }


        public ICollection<AlunoCurso> Alunos { get; set; }
        public ICollection<Modulo> Modulos { get; set; }

    }
}
