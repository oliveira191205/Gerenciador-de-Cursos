﻿using Gerenciador_de_Cursos.Bussiness.Entities;
using Gerenciador_de_Cursos.Data.Context;
using Gerenciador_de_Cursos.Bussiness.Interfaces.IRepositories;
using Microsoft.EntityFrameworkCore;

namespace Gerenciador_de_Cursos.Data.Repositories
{
    public class AlunoRepository : IAlunoRepository
    {
        private readonly DataContext _db;

        public AlunoRepository(DataContext db)
        {
            _db = db;
        }

        public void CreateAluno(Aluno aluno)
        {
            _db.Alunos.Add(aluno);
            _db.SaveChanges();
        }

        public Aluno FindById(Guid id)
        {
            return _db.Alunos.
                Select(aluno => aluno)
                .Where(aluno => aluno.Id == id)
                .First();
        }

        public Aluno GetAlunoByEmail(string email)
        {
            return _db.Alunos
                .Select(aluno => aluno)
                .Where(aluno => aluno.Email == email)
                .First();
        }

        public List<Aluno> GetAlunos()
        {
            List<Aluno> result = _db.Alunos
                .Select(aluno => aluno)
                .ToList();

            return result;
        }
    }
}
