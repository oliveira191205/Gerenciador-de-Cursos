﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Modulo
    {
        public Guid Id { get; set; }

        public List<> Etapas { get; set; }
    }
}
