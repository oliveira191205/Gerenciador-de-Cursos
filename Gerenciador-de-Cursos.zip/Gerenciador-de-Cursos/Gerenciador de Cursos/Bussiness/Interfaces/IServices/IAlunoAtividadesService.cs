﻿namespace Gerenciador_de_Cursos.Bussiness.Interfaces.IServices
{
    public interface IAlunoAtividadesService
    {
    }
}
