﻿using Gerenciador_de_Cursos.Bussiness.Entities;
using Microsoft.EntityFrameworkCore;

namespace Gerenciador_de_Cursos.Data.Context
{
    public class DataContext : DbContext
    {
        public DbSet<Aluno> Alunos { get; set; }
        public DbSet<Curso> Curso { get; set; }
        public DbSet<Instrutor> Instrutor { get; set; }
        public DbSet<AlunoAtividades> AlunoAtividades { get; set; }
        public DbSet<AlunoCurso> AlunoCursos { get; set; }
        public DbSet<AtividadesCurso> AtividadesCurso { get; set; }


        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Aluno>()
                .HasKey(aluno => aluno.Id);

            modelBuilder.Entity<Curso>()
                .HasKey(curso => curso.Id);

            modelBuilder.Entity<Instrutor>()
                .HasKey(instrutor => instrutor.Id);

            modelBuilder.Entity<AlunoAtividades>()
                .HasKey(alunoatividades => alunoatividades.Id);

            modelBuilder.Entity<AlunoCurso>()
                .HasKey(alunocurso => alunocurso.Id);

            modelBuilder.Entity<AtividadesCurso>()
                .HasKey(atividadescurso => atividadescurso.Id);



            modelBuilder.Entity<Curso>()
                .HasOne(curso => curso.Instrutor)
                .WithMany(instrutor => instrutor.Cursos)
                .HasForeignKey(curso => curso.InstrutorId);

            modelBuilder.Entity<AlunoCurso>()
                .HasOne(alunocurso => alunocurso.Aluno)
                .WithMany(aluno => aluno.Cursos)
                .HasForeignKey(alunocurso => alunocurso.AlunoId);


            modelBuilder.Entity<AlunoCurso>()
                .HasOne(alunocurso => alunocurso.Curso)
                .WithMany(curso => curso.Alunos)
                .HasForeignKey(alunocurso => alunocurso.CursoId);

            modelBuilder.Entity<AtividadesCurso>()
                .HasOne(atividadecurso => atividadecurso.Curso)
                .WithMany(curso => curso.Atividades)
                .HasForeignKey(atividadecurso => atividadecurso.CursoId);


            modelBuilder.Entity<AlunoAtividades>()
                .HasOne(atividadealuno => atividadealuno.Aluno)
                .WithMany(atividades => atividades.Atividades)
                .HasForeignKey(atividadealuno => atividadealuno.AlunoId);

            modelBuilder.Entity<AlunoAtividades>()
                .HasOne(alunoatividade => alunoatividade.Curso)
                .WithMany()
                .HasForeignKey(alunoatividade => alunoatividade.CursoId);

            modelBuilder.Entity<AlunoAtividades>()
                .HasOne(alunoatividades => alunoatividades.AtividadeCurso)
                .WithMany(alunocurso => alunocurso.Alunos)
                .HasForeignKey(alunoatividades => alunoatividades.AtividadesCursoId);

            base.OnModelCreating(modelBuilder);
        }
    }
}
