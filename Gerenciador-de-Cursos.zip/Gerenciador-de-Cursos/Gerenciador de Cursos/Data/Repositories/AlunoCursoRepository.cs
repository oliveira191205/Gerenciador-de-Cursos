﻿using Gerenciador_de_Cursos.Bussiness.Entities;
using Gerenciador_de_Cursos.Data.Context;
using Gerenciador_de_Cursos.Bussiness.Interfaces.IRepositories;
using Microsoft.EntityFrameworkCore;

namespace Gerenciador_de_Cursos.Data.Repositories
{
    public class AlunoCursoRepository : IAlunoCursoRepository
    {
        private readonly DataContext _db;

        public AlunoCursoRepository(DataContext db)
        {
            _db = db;
        }

        public void CreateAlunoCurso(AlunoCurso alunoCurso)
        {
            _db.AlunoCursos.Add(alunoCurso);
            _db.SaveChanges();
        }

        public AlunoCurso FindById(Guid id)
        {
            return _db.AlunoCursos
                .Select(alunocursos => alunocursos)
                .Where(alunocursos => alunocursos.Id == id)
                .First();
        }

        public List<AlunoCurso> GetAlunoCursos()
        {
            List<AlunoCurso> result = _db.AlunoCursos
                .Select(alunocursos => alunocursos)
                .ToList();

            return result;
        }

        public List<AlunoCurso> GetCursosByAlunoId(Guid alunoId)
        {
            List<AlunoCurso> result = _db.AlunoCursos
                .Select(alunocursos => alunocursos)
                .Where(alunocursos => alunocursos.AlunoId == alunoId)
                .ToList();

            return result;
        }

        public List<AlunoCurso> GetAlunosByCursoId(Guid cursoId)
        {
            List<AlunoCurso> result = _db.AlunoCursos
                .Select(alunocursos => alunocursos)
                .Where(alunocursos => alunocursos.CursoId == cursoId)
                .ToList();

            return result;

        }
    }
}
