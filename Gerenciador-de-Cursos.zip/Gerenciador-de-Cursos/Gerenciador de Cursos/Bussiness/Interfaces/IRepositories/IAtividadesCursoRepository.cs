﻿namespace Gerenciador_de_Cursos.Bussiness.Interfaces.IRepositories
{
    public interface IAtividadesCursoRepository
    {
    }
}
