﻿using Gerenciador_de_Cursos.Bussiness.Entities;
using Gerenciador_de_Cursos.Data.Context;
using Gerenciador_de_Cursos.Bussiness.Interfaces.IRepositories;
using Microsoft.EntityFrameworkCore;

namespace Gerenciador_de_Cursos.Data.Repositories
{
    public class InstrutorRepository : IInstrutorRepository
    {
        private readonly DataContext _db;

        public InstrutorRepository(DataContext db)
        {
            _db = db;
        }

        public void CreateInstrutor(Instrutor instrutor)
        {
            _db.Instrutor.Add(instrutor);
            _db.SaveChanges();
        }

        public Instrutor FindById(Guid id)
        {
            return _db.Instrutor
                .Select(i => i)
                .Where(i => i.Id == id)
                .First();
        }

        public List<Instrutor> GetInstrutores()
        {
            List<Instrutor> result = _db.Instrutor
                .Select(instrutor =>  instrutor)
                .ToList();

            return result;
        }
    }
}