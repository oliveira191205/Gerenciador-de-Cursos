﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Conteudo
    {
        public Guid Id { get; set; }
        public string Título { get; set; }
        public string TextoInformativo { get; set; }
        public byte[] Midias { get; set; }

    }
}
