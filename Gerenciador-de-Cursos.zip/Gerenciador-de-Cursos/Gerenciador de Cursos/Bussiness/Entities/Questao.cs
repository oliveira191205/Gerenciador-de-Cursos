﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Questao
    {

        public Guid Id { get; set; }


        public Guid CursoId { get; set; }
        public Curso Curso { get; set; }


        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public string Enunciado { get; set; }

        public int RespostaCorreta { get; set; }

        //public int RespostaAluno { get; set; }
        public bool Acertou {  get; set; }
        public DateTime PrazoEnvio { get; set; }
    }
}
