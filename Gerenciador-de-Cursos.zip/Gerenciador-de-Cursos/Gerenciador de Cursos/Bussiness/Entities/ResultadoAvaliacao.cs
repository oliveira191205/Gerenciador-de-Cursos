﻿using System.Diagnostics.CodeAnalysis;

namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class ResultadoAvaliacao
    {
        public Guid Id { get; set; }

        public Guid CursoId { get; set; }
        public Curso Curso { get; set; }


        public Guid AlunoId { get; set; }
        public Aluno Aluno { get; set; }

        public double NotaFinal { get; set; }
    }
}
