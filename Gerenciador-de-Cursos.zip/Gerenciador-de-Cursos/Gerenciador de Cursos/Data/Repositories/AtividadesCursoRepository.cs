﻿using Gerenciador_de_Cursos.Bussiness.Entities;
using Gerenciador_de_Cursos.Data.Context;
using Gerenciador_de_Cursos.Bussiness.Interfaces.IRepositories;
using Microsoft.EntityFrameworkCore;

namespace Gerenciador_de_Cursos.Data.Repositories
{
    public class AtividadesCursoRepository : IAtividadesCursoRepository
    {
        private readonly DataContext _db;

        public AtividadesCursoRepository(DataContext db)
        {
            _db = db;
        }

        public void CreateAtividadeCurso(AtividadesCurso atividade)
        {
            _db.AtividadesCurso.Add(atividade);
            _db.SaveChanges();
        }

        public AtividadesCurso FindById(Guid id)
        {
            return _db.AtividadesCurso
                .Select(atividadescursos => atividadescursos)
                .Where(atividadescurso => atividadescurso.Id == id)
                .First();
        }

        public List<AtividadesCurso> GetAtividadesByCursoId(Guid cursoId)
        {
            List<AtividadesCurso> result = _db.AtividadesCurso
                .Select(atividadescurso => atividadescurso)
                .ToList();

            return result;
        }

        public List<AtividadesCurso> GetAtividadesCursos()
        {
            return _db.AtividadesCurso
                .Include(ac => ac.Curso)
                .ToList();
        }
    }
}