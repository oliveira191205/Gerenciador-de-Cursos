﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Avaliacao
    {
        public Guid Id { get; set; }

        public Guid IdCurso { get; set; }
        public Curso Curso { get; set; }

        public Guid IdAluno { get; set; }
        public Aluno Aluno { get; set; }


        public ICollection<Questao> Questaos { get; set; } = new List<Questao>();


        public double NotaFinal { get; set; }

        public DateTime DataRealizacao { get; set; }

        public DateTime Prazo { get; set;}

    }
}
