﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class RespostaAluno
    {
        public Guid Id { get; set; }


        public Guid CursoId { get; set; }
        public Curso Curso { get; set; }


        public Guid AlunoId { get; set; }
        public Aluno Aluno { get; set; }


        public Guid QuestaoId { get; set; }
        public Questao Questao { get; set; }


        public int Resposta { get; set; }
        public float Nota { get; set; }
        public bool Concluido { get; set; }
        public DateTime DataEnvio { get; set; }

    }
}
