﻿using Gerenciador_de_Cursos.Bussiness.Entities;
using Gerenciador_de_Cursos.Data.Context;
using Gerenciador_de_Cursos.Bussiness.Interfaces.IRepositories;
using Microsoft.EntityFrameworkCore;

namespace Gerenciador_de_Cursos.Data.Repositories
{
    public class CursoRepository : ICursoRepository
    {
        private readonly DataContext _db;

        public CursoRepository(DataContext db)
        {
            _db = db;
        }

        public void CreateCurso(Curso curso)
        {
            _db.Curso.Add(curso);
            _db.SaveChanges();
        }

        public Curso FindById(Guid id)
        {
            return _db.Curso
                .Select(curso => curso)
                .Where(curso => curso.Id == id)
                .First();
        }

        public List<Curso> GetCursos()
        {
            List<Curso> result = _db.Curso
                .Select(curso => curso)
                .ToList();

            return result;
        }
    }
}
