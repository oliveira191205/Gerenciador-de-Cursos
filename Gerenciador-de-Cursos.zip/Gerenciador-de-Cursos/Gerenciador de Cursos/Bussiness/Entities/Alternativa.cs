﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Alternativa
    {
        public Guid Id { get; set; }

        public Guid QuestaoId { get; set; }
        public Questao Questao { get; set; }

        public string AlternativaTitulo { get; set; }
    }
}
