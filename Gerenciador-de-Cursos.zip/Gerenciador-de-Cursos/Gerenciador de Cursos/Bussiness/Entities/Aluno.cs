﻿namespace Gerenciador_de_Cursos.Bussiness.Entities
{
    public class Aluno
    {
        public Guid Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }
        public int CPF { get; set; }
        public DateTime DataNascimento { get; set; }
        public DateTime DataCadastro { get; set; } 

        public ICollection<AlunoCurso> Cursos { get; set; }
        //public ICollection<Questao> Questoes { get; set; }
    }
}
